---
name: informes-happyforce
description: Publica y gestiona informes en los espacios de cliente de informes.myhappyforce.com (HTML, PDF, vídeos MP4 y enlaces) usando el conector MCP «informes». Úsala siempre que alguien de Happyforce quiera subir, publicar, compartir, sustituir o revisar un informe, un vídeo o un PDF en el espacio de un cliente («sube estos vídeos al espacio de Sabadell», «publica el informe de clima de Acme», «¿qué informes tiene X?», «da acceso a ana@cliente.com»), aunque no mencione la plataforma por su nombre.
---

# Informes Happyforce: publicar en los espacios de cliente

Customer Advisory comparte informes con cada cliente en un **espacio privado**
(`informes.myhappyforce.com/c/{cliente}`). Solo entran los emails con acceso
(login por enlace mágico). Cada informe vive en `/r/{slug}` y puede ser un HTML
autocontenido, un PDF, un vídeo o un enlace externo.

Todo se hace con las herramientas del conector MCP **informes**:
`list_clients`, `get_client`, `list_public_reports`, `create_client`,
`add_member`, `prepare_upload`, `publish_report`, `update_report`.

## 0. Comprueba la conexión (y guía la configuración si falta)

Si tienes herramientas como `list_clients` y `prepare_upload` del servidor
**informes**, llama a `list_clients`: si responde, sigue al paso 1.

Si no aparecen, o devuelven «Token no válido», **no sigas con la petición**:
acompaña a la persona a conectarse y retómala después. Solo puede hacerlo
alguien con email `@myhappyforce.com`.

**Nunca pidas el token en el chat.** Actúa en nombre de su dueño con permisos
de administrador y quedaría guardado en la conversación. Lo ejecuta la persona
en su propio terminal. Si aun así lo pega aquí, no lo repitas y recomiéndale
revocarlo en `/admin/claude` y crear otro cuando termine.

Mira dónde estás y sigue el caso que toque:

**A. Claude Code o pestaña Code de Claude Desktop** (tienes terminal).
Comprueba primero si ya está configurado:

```bash
claude mcp get informes 2>&1 | head -5
```

- **No está configurado.** Explica estos pasos:
  1. Abrir https://informes.myhappyforce.com/admin/claude y entrar con su email
     de Happyforce (le llega un enlace por correo).
  2. Pulsar «Crear token», con el nombre del ordenador (p. ej. «Portátil de
     Marta»).
  3. Copiar el comando de la sección «Claude Code» (ya lleva su token) y
     ejecutarlo en **otra ventana de terminal** (la app Terminal, o el panel
     de terminal de Claude Desktop). No en este chat ni con `!`, para que el
     token no quede en la conversación.
  4. Instalar también la skill con el comando de esa misma página, si no la
     tiene.
  5. Abrir **una sesión nueva** de Claude (los conectores se cargan al
     empezar) y volver a pedir lo que quería.
- **Está configurado, pero da «Token no válido».** El token se revocó o se
  copió mal. Que lo quite con `claude mcp remove informes -s user` en su
  terminal y repita los pasos 1-3 y 5 con un token nuevo.
- **Está configurado y no conecta** (error de red o de servidor): que lo
  intente de nuevo en una sesión nueva y, si sigue, que avise a Producto.

**B. Chat de Claude Desktop** (sin terminal).

1. Pasos 1 y 2 del caso A.
2. Comprobar que tiene Node.js: en Terminal, `node -v`. Si no responde, que lo
   instale desde https://nodejs.org (versión LTS).
3. En Claude Desktop: Ajustes → Desarrollador → Editar configuración. Abrir
   `claude_desktop_config.json` y pegar el bloque de la sección «Chat de
   Claude Desktop» de `/admin/claude`. Si el fichero ya tiene otros servidores
   en `mcpServers`, que añada solo la entrada `informes` dentro, sin duplicar
   `mcpServers`.
4. Cerrar Claude Desktop del todo (Cmd+Q) y volver a abrirlo.

Avísale de que desde el chat podrá consultar espacios, dar accesos y publicar
enlaces, pero **para subir ficheros** (HTML, PDF, vídeos) tiene que usar la
pestaña Code (caso A), porque la subida se hace con `curl`.

**C. claude.ai en el navegador o en el móvil.** Aquí no se puede conectar.
Que use Claude Desktop (caso A o B), o el panel
https://informes.myhappyforce.com/admin para hacerlo a mano.

Cuando vuelva con la conexión hecha, comprueba con `list_clients` que
funciona antes de seguir.

## 1. Identifica el cliente

- `list_clients` si no sabes el slug; `get_client` para ver quién tiene acceso y
  qué informes tiene ya.
- Mira las tarjetas de los informes existentes de ese cliente y **sigue su
  estilo** (badges, tono de la descripción, color de portada) para que el
  espacio quede coherente.
- Si el cliente no existe, propón `create_client` (nombre, color de marca) y
  espera el sí.

## 2. Prepara cada fichero

**Vídeo.** Comprueba formato y peso antes de subir:

```bash
ffprobe -v error -show_entries format=duration,size:stream=codec_name,width,height -of compact "VIDEO"
```

Va bien tal cual si es **MP4 con H.264 + AAC y pesa menos de ~45 MB**. Si pesa
más, es `.mov`/HEVC u otro códec, propón comprimirlo (conserva el original):

```bash
ffmpeg -i "ENTRADA" -c:v libx264 -crf 23 -preset medium -vf "scale=-2:'min(1080,ih)'" -c:a aac -b:a 128k -movflags +faststart "SALIDA.mp4"
```

Si sigue por encima de 50 MB, sube el `-crf` a 26-28. El límite por fichero
del almacenamiento es 50 MB.

Para saber **de qué trata** el vídeo (no puedes verlo, pero sí leer
imágenes), saca 6 fotogramas repartidos por su duración en una carpeta
temporal y míralos:

```bash
D=$(ffprobe -v error -show_entries format=duration -of csv=p=0 "VIDEO")
OUT=$(mktemp -d)
for i in 0 1 2 3 4 5; do
  ffmpeg -v error -ss "$(echo "$D * (0.03 + $i * 0.18)" | bc -l)" -i "VIDEO" -frames:v 1 -vf "scale=960:-2" "$OUT/frame-$i.jpg"
done
ls "$OUT"
```

Lee cada `frame-N.jpg`. Busca la diapositiva o el rótulo de título, el nombre
del cliente o del área, el periodo y las cifras que aparezcan en pantalla:
de ahí salen el título, la descripción y las stats. Usa solo lo que se lee
con claridad. Si después de mirar los fotogramas sigues sin saber de qué trata
(por ejemplo, es una grabación de pantalla sin rótulos), **pregunta en una
línea** qué cuenta el vídeo antes de redactar la tarjeta. No inventes el
contenido a partir del nombre del fichero. Borra la carpeta temporal al
terminar.

**HTML.** Lee el fichero: el título está en `<title>`/`<h1>`, el resumen en el
hero o la introducción, y los datos clave en las cifras grandes del hero.

**PDF.** Lee las primeras páginas para sacar título, resumen y cifras.

**Artefacto de Claude** (un informe hecho como artefacto o página en Claude).
Es un HTML, así que se publica como HTML, pero antes hay que conseguir el
fichero y asegurarse de que funciona fuera de Claude.

1. **Consigue el HTML.**
   - Si ya es un `.html` local, úsalo.
   - Si es un enlace `claude.ai/artifact/…` o `claude.ai/code/artifact/…`, léelo
     con la herramienta **Artifact** (`action: "read"`). Si la persona es la
     dueña, devuelve el HTML completo y dice en qué fichero lo ha guardado. Si
     devuelve solo un resumen, el artefacto es de otra persona: pide que lo
     suba su autor o que te pase el `.html`. **Nunca reconstruyas un informe a
     partir del resumen.**
   - Si no tienes la herramienta Artifact (por ejemplo, el artefacto se hizo en
     el chat de claude.ai), pide que lo descarguen desde el menú del artefacto
     (Descargar) y te pasen la ruta.
   - Si lo descargado es un `.jsx` (artefacto React del chat), no es una página:
     pide que lo exporten como HTML, o conviértelo tú en un HTML autocontenido
     (React y ReactDOM desde un CDN) y compruébalo en el navegador antes de
     seguir.
2. **Comprueba que no depende de Claude:**

   ```bash
   grep -noE 'window\.claude[.a-zA-Z]*|https://claude\.ai/[^"'"'"' )]*|(src|href)="(\./|/[a-z]|[a-zA-Z0-9_-]+\.(js|css|png|jpe?g|svg|webp|gif|json|csv))[^"]*"|fetch\(.[^h][^)]*\)' "INFORME.html"
   ```

   - `window.claude…` (datos guardados, estado compartido, comentarios,
     preguntas a Claude): fuera de Claude **no funciona**. Explica qué parte
     dejará de funcionar y propón quitarla o fijar sus datos en el HTML. No lo
     publiques sin un sí.
   - URLs de `claude.ai` (imágenes o ficheros del artefacto) o rutas relativas
     (`./datos.json`, `estilos.css`, `logo.png`, `fetch('datos.json')`): el
     cliente no podrá cargarlas.
     Descárgalas (con Artifact `read` y `path`, o pídeselas a la persona) y
     mételas en el HTML: imágenes como `data:` en base64, y CSS, JS y datos
     inline.
   - Las librerías y fuentes de CDNs públicos (cdnjs, jsdelivr, unpkg, Google
     Fonts) funcionan tal cual.
3. **Ábrelo en local** si tienes navegador, para ver que carga entero y que los
   gráficos se pintan. Después sigue como con cualquier HTML: la tarjeta sale
   del propio contenido.
4. Cuando el artefacto se actualice, sube la nueva versión con `update_report`
   (mismo slug), no como informe nuevo.

## 3. Redacta la tarjeta

- **title**: el del informe, ≤ 70 caracteres. Para una serie, nómbralos igual
  («EnergyMap · Banca Particulares», «EnergyMap · Banca Empresas»…).
- **description**: 1-2 frases (≤ 240 caracteres) que digan qué va a encontrar el
  cliente, no cómo se hizo. En español y de tú a tú, como el resto de Happyforce.
- **badges**: 1-3 etiquetas cortas (producto o tipo de informe y periodo:
  «EnergyMap», «Q3 2026»).
- **stats**: hasta 3 cifras **que aparezcan en el propio informe** (en un
  vídeo, las que se leen en los fotogramas). Nunca te las inventes; si no hay,
  déjalo vacío.
- **cover**: el color que ya use ese cliente, o `accent-orange` por defecto.
- **published_at**: hoy, salvo que te digan otra fecha.

## 4. Confirma antes de publicar

Publicar en un espacio lo hace **visible para el cliente**. Antes de subir nada,
enseña un resumen y espera el sí:

| Fichero | Tipo | Peso | Título | Cliente |
|---|---|---|---|---|

Con varios ficheros (p. ej. 3 vídeos), una sola tabla y una sola confirmación.

## 5. Sube y publica

Para cada fichero:

1. `prepare_upload` con el nombre del fichero → devuelve `staged_path` y
   `upload_command`.
2. Ejecuta el `upload_command` sustituyendo `<RUTA_DEL_FICHERO>` por la ruta
   local (entre comillas). Con vídeos dale un timeout amplio (≥ 5 min). Debe
   devolver un JSON con `"Key"`.
3. `publish_report` con `client`, `staged_path` y los datos de la tarjeta.

Para un **enlace** (Drive, Canva…): `publish_report` con `external_url`, sin
subida. Avisa de que la privacidad real depende de los permisos del enlace.

Para **sustituir** el fichero de un informe existente (nueva versión):
`prepare_upload` + subida + `update_report` con `slug` y `staged_path`. La URL
`/r/{slug}` no cambia. `update_report` también sirve para corregir solo la
tarjeta (pasa solo los campos que cambian).

## 6. Cierra

- Da el enlace de cada informe (`url`) y el del espacio (`space_url`).
- Si el espacio no tiene a nadie con acceso, pregunta si hay que darlo.
  `add_member` **envía un email al cliente en el momento**: no lo hagas sin un sí
  explícito con los emails exactos.

## Qué no se hace desde aquí

Quitar accesos y borrar informes o clientes: solo desde el panel
https://informes.myhappyforce.com/admin. Si te lo piden, da el enlace
`edit_url`/`admin_url` correspondiente.

## Errores frecuentes

- **«Ya existe un informe con la URL…»**: pasa otro `slug`, o usa
  `update_report` si es una nueva versión del mismo informe.
- **«No encuentro el fichero subido»**: la subida falló o pasaron más de 2 h.
  Repite `prepare_upload` y la subida.
- **La subida devuelve 413 / «maximum allowed size»**: el fichero supera
  50 MB. Comprímelo (paso 2).
